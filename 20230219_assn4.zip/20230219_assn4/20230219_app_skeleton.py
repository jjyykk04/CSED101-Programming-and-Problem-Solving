import tkinter as tk                                                               #tkinter 모듈을 불러옴
from model_skeleton import Board                                                   #model_skeleton에서 Board class를 불러옴

TITLE = "Minesweeper"                                                              
BTN_WIDTH = 30
BTN_HEIGHT = 30
BORDER_SIZE = 2
OUTTER_PADDING_SIZE = 10
BACKGROUND_COLOR = "#DCDCDC"


class App(tk.Frame):
    def __init__(self, master, title, nummine, height, width):
        super(App, self).__init__(master)
        master.title(title)
        self.board = Board()

        master.geometry(
            f"{width * (BTN_WIDTH) + (OUTTER_PADDING_SIZE + BORDER_SIZE) * 2}x{(height + 1) * (BTN_HEIGHT) + (OUTTER_PADDING_SIZE + BORDER_SIZE) * 5}")

        self.base_icon = tk.PhotoImage(file="imgs/smile.png")                      #이미지 초기화
        self.success_icon = tk.PhotoImage(file="imgs/sunglasses.png")
        self.fail_icon = tk.PhotoImage(file="imgs/skull.png")
        self.flag_icon = tk.PhotoImage(file="imgs/flag.png")
        self.bomb_icon = tk.PhotoImage(file="imgs/bomb.png")

        self["bg"] = BACKGROUND_COLOR                                              #프레임 설정
        self["relief"] = tk.SUNKEN
        self["bd"] = BORDER_SIZE
        self["padx"] = OUTTER_PADDING_SIZE
        self["pady"] = OUTTER_PADDING_SIZE

        head = tk.Frame(self, bg=BACKGROUND_COLOR, relief=tk.SUNKEN, bd=BORDER_SIZE)                    #상단 프레임 생성
        head.grid(row=0, column=0, columnspan=width, pady=(0, OUTTER_PADDING_SIZE), sticky='ew')

        start_wrapper = tk.Frame(head, width=BTN_WIDTH, height=BTN_HEIGHT)                              #초기화 버튼 프레임 생성
        start_wrapper.pack_propagate(0)
        start_wrapper.pack(padx=OUTTER_PADDING_SIZE, pady=OUTTER_PADDING_SIZE)

        start = tk.Button(start_wrapper, image=self.base_icon, bd=BORDER_SIZE)                          #초기화 버튼 생성
        start.bind("<Button-1>", lambda event: reset_click(nummine, height, width))
        start.pack(expand=True, fill='both')

        menu_bar = tk.Menu(master)                                                                      # 난이도 메뉴 생성
        master.config(menu=menu_bar)
        
        level_menu = tk.Menu(menu_bar, tearoff=0)                                                       # 난이도 메뉴에 옵션 추가
        menu_bar.add_cascade(label="난이도", menu=level_menu)
        
        level_menu.add_command(label="Easy", command=lambda: make_button(10, 10, 10)) 
        level_menu.add_command(label="Normal", command=lambda: make_button(30, 15, 15))
        level_menu.add_command(label="Hard", command=lambda: make_button(50, 20, 20))

        body = tk.Frame(self, bg=BACKGROUND_COLOR, relief=tk.SUNKEN, bd=BORDER_SIZE)                    # 본문 부분 프레임 생성
        body.grid(row=1, column=0, columnspan=width)


        def make_button(nummine, height, width) :                                                       #버튼 초기화 및 생성 매서드

            for widget in body.winfo_children():                                                        #기존 버튼 초기화
                widget.destroy()

            self.btn_list = []
            self.btn_wrapper_list = []
            for row in range(height):
                row_list = []
                row_w_list = []
                for col in range(width):
                    btn_wrapper = tk.Frame(body, width=BTN_WIDTH, height=BTN_HEIGHT)                    #버튼 프레임 생성
                    btn_wrapper.pack_propagate(0)
                    btn_wrapper.grid(row=row, column=col)
                    row_w_list.append(btn_wrapper)

                    btn = tk.Button(btn_wrapper, bg=BACKGROUND_COLOR, bd=BORDER_SIZE)                   #버튼 생성
                    btn.bind("<Button-1>", lambda e, y=row, x=col: onLeftClick(y, x))
                    btn.bind("<Button-3>", lambda e, y=row, x=col: onRightClick(y, x))
                    row_list.append(btn)
                    btn.pack(expand=True, fill='both')

                self.btn_list.append(row_list)
                self.btn_wrapper_list.append(row_w_list)
                
            self.pack()

            self.board.reset(nummine, height, width)


            def onLeftClick(y, x):                                                                      # 왼쪽 클릭 이벤트 핸들러 매서드
                if self.board.checkReveal(y, x) == True or self.board.checkFlag(y, x) == True :         # 밝혀져 있거나 깃발이 있는 경우
                    None

                elif self.board.checkReveal(y, x) == False and self.board.checkFlag(y, x) == False :    # 안 밝혀져 있고 깃발이 없는 경우

                    self.value = self.board.unveil(y, x)

                    if self.value == None :                                                             #unveil함수의 리턴값이 None일 때
                        for i in range(height) :
                            for j in range(width) :
                                if self.board.checkReveal(i, j) == True :
                                    self.btn_list[i][j].destroy()
                                    if self.board.getNumOfNearMines(i, j) == 0 :
                                        la = tk.Label(self.btn_wrapper_list[i][j], text="", width=BTN_WIDTH, height=BTN_HEIGHT, relief=tk.SOLID, bd = 1)
                                        la.pack()
                                    else :
                                        la = tk.Label(self.btn_wrapper_list[i][j], text=str(self.board.getNumOfNearMines(i, j)), width=BTN_WIDTH, height=BTN_HEIGHT, relief=tk.SOLID, bd = 1)
                                        la.pack()

                                    if self.board.getNumOfRevealedPanels() == height*width - nummine :
                                        start.config(image=self.success_icon)
                            
                    
                    elif self.value == -1 :                                                              #unveil함수의 리턴값이 -1일 때
                        self.btn_list[y][x].destroy()
                        la = tk.Label(self.btn_wrapper_list[y][x], width=BTN_WIDTH, height=BTN_HEIGHT, relief=tk.SOLID, bd = 1, image=self.bomb_icon)
                        la.pack()
                        for i in range(height) :
                            for j in range(width) :
                                if self.btn_list[i][j] != self.btn_list[y][x] :
                                    self.btn_list[i][j].destroy()
                                    if self.board.getNumOfNearMines(i, j) == None :
                                        la = tk.Label(self.btn_wrapper_list[i][j], width=BTN_WIDTH, height=BTN_HEIGHT, relief=tk.SOLID, bd = 1, image=self.bomb_icon)
                                        la.pack()
                                    
                                    elif self.board.getNumOfNearMines(i, j) > 0 :
                                        la = tk.Label(self.btn_wrapper_list[i][j], text=str(self.board.getNumOfNearMines(i, j)), width=BTN_WIDTH, height=BTN_HEIGHT, relief=tk.SOLID, bd = 1)
                                        la.pack()

                                    elif self.board.getNumOfNearMines(i, j) == 0 :
                                        la = tk.Label(self.btn_wrapper_list[i][j], text="", width=BTN_WIDTH, height=BTN_HEIGHT, relief=tk.SOLID, bd = 1)
                                        la.pack()

                        start.config(image=self.fail_icon)


            def onRightClick(y, x):                                                                      # 오른쪽 클릭 이벤트 핸들러 매서드

                if self.board.checkFlag(y, x) == True :
                    
                    self.btn_list[y][x].config(image="")
                    self.board.toggleFlag(y, x)
                    
                elif self.board.checkFlag(y, x) == False :
                    
                    self.btn_list[y][x].config(image=self.flag_icon)
                    self.board.toggleFlag(y, x)
                    

        def reset_click(nummine, height, width) :                                                         # 초기화 버튼 클릭 이벤트 핸들러 매서드
            
            start.config(image=self.base_icon)

            if len(self.btn_list) == 10 :
                nummine, height, width = 10, 10, 10
            elif len(self.btn_list) == 15 :
                nummine, height, width = 30, 15, 15
            elif len(self.btn_list) == 20 :
                nummine, height, width = 50, 20, 20

            make_button(nummine, height, width)

        make_button(nummine, height, width)


if __name__ == '__main__':
    TITLE = "Minesweeper"
    NUMMUNE = 10
    HEIGHT = 10
    WIDTH = 10

    root = tk.Tk()
    app = App(root, TITLE, NUMMUNE, HEIGHT, WIDTH)
    app.mainloop()

