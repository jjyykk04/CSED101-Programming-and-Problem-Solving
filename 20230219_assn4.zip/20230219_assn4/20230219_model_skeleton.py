import random

class Panel:                                                           #지뢰 찾기 게임의 각 칸에 해당하는 class
    def __init__(self):
        self.isRevealed = False                            #해당 panel이 밝혀진 상태인지를 나타내는 bool type 변수
        self.hasFlag = False                                    #해당 panel이 flag를 보유하고 있는지를 나타내는 bool type 변수

    def toggleFlag(self):                                  #해당 panel의 hasFlag를 toggle하는 매서드
        if self.hasFlag == True :
            self.hasFlag = False

        elif self.hasFlag == False :
            self.hasFlag = True

    def unveil(self):                                      #해당 panel을 밝혀진 상태로 변경하는 매서드
       self.isRevealed = True

    def CheckM(self):
        pass


class EmptyPanel(Panel):                                               #지뢰가 존재하지 않는 칸을 의미하는 class
    def __init__(self):
        super().__init__()
        self.num0fNearMines = 0                                 #해당 panel과 인접한 mine의 수를 저장하는 num type 변수

    def addNumOfNearMines(self):                           #해당 panel의 numOfNearMines의 값을 1 증가하는 매서드
        self.num0fNearMines += 1

    def unveil(self):                                      #부모인 Panel의 unveil을 수행하는 매서드
        super().unveil()
        return self.num0fNearMines
    
    def CheckM(self):
        super().CheckM()
        return "ep"
    

class MinePanel(Panel):                                                #지뢰가 존재하는 칸을 의미하는 class
    def unveil(self):
        super().unveil()
        return -1
    
    def CheckM(self):
        super().CheckM()
        return "mp"
    

class Board:                                                           #지뢰 찾기 게임에 사용되는 모든 기능을 포함하는 class

    def reset(self, numMine, height, width):                           #Board를 초기화하는 매서드
        self.numMine = numMine
        self.height = height
        self.width = width
        
        self.panels = [[EmptyPanel() for _ in range(width)] for _ in range(height)]

        mine_positions = random.sample(range(height * width), numMine)       #랜덤한 리스트
        for i in mine_positions:
            y, x = divmod(i, width)
            self.panels[y][x] = MinePanel()                                  #지뢰를 랜덤한 좌표에 배치

        for y in range(height):
            for x in range(width):
                if not isinstance(self.panels[y][x], MinePanel):
                    for dy in [-1, 0, 1]:
                        for dx in [-1, 0, 1]:
                            ny, nx = y + dy, x + dx
                            if 0 <= ny < height and 0 <= nx < width and isinstance(self.panels[ny][nx], MinePanel):
                                self.panels[y][x].addNumOfNearMines()
                                 
    def getNumOfRevealedPanels(self):                                  #현재 board에 밝혀져 있는 Panel의 개수를 return하는 매서드
        NumOfRevealedPanels = 0

        for i in range(self.height) :
            for j in range(self.width) :
                if self.panels[i][j].isRevealed == True :
                    NumOfRevealedPanels += 1
        
        return NumOfRevealedPanels

    def unveil(self, y, x):                                            #panels의 y행 x열에 위치한 Panel을 밝히는 매서드 
        if self.panels[y][x].isRevealed or (self.panels[y][x].hasFlag and self.panels[y][x].CheckM == "mp") :             
            return

        elif self.panels[y][x].unveil() == -1 :
            return -1

        elif self.panels[y][x].unveil() == 0:
            
            if self.panels[y][x].hasFlag == True :                 #만약 깃발이 존재하는 칸에도 반복되었고, 해당 칸이 지뢰가 아닌 경우 해당 칸의 깃발을 제거하고, 밝혀 냄
                self.panels[y][x].toggleFlag()
            
            self.directions = [(-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1)]

            for dy, dx in self.directions:
                ny, nx = y + dy, x + dx

               
                if 0 <= ny < self.height and 0 <= nx < self.width:
                    self.unveil(ny, nx)

    def toggleFlag(self, y, x):                                        #panels의 y행 x열에 위치한 Panel의 flag를 toggle하는 매서드
        self.panels[y][x].toggleFlag()

    def checkReveal(self, y, x):                                       #panels의 y행 x열에 위치한 Panel이 밝혀져 있는지 확인하는 매서드
        return self.panels[y][x].isRevealed
            
    def checkFlag(self, y, x):                                         #panels의 y행 x열에 위치한 Panel에 flag가 있는지 확인하는 매서드
        return self.panels[y][x].hasFlag
            
    def checkMine(self, y, x):                                         #panels의 y행 x열에 위치한 Panel에 mine이 있는지 확인하는 매서드
        if self.panels[y][x].CheckM() == "mp" :
            return True 
        elif self.panels[y][x].CheckM() == "ep" :
            return False

    def getNumOfNearMines(self, y, x):                                 #panels의 y행 x열에 위치한 Panel에 인접한 mine의 수를 return하는 매서드
        if self.panels[y][x].CheckM() == "ep" :
            return self.panels[y][x].num0fNearMines
    

